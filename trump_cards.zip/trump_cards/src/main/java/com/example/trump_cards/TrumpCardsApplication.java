package com.example.trump_cards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrumpCardsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrumpCardsApplication.class, args);
	}

}
