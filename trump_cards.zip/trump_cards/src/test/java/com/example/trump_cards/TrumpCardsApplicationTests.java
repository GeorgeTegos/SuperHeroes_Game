package com.example.trump_cards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrumpCardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
